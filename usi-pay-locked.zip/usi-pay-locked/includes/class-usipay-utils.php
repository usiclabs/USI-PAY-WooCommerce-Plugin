<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class USIPAY_Utils {

    public static function locked_tokens() {
        // USDC (Base) + USI
        return [
            [
                "symbol"   => "USDC",
                "name"     => "USD Coin (Base)",
                "address"  => "0x833589fCD6eDb6E08f4c7C32D4f71B54b268cB6B",
                "decimals" => 6,
                "manual_usd" => 1.0
            ],
            [
                "symbol"   => "USI",
                "name"     => "USIC Token",
                "address"  => "0x987603A52d8B966E10FBD29DcB1A574049E25B07",
                "decimals" => 18,
                "manual_usd" => 0.01
            ]
        ];
    }

    public static function get_settings() {
        $defaults = [
            'enabled'            => 'yes',
            'title'              => 'USI PAY',
            'description'        => 'Pay with USDC or USI on the Base network.',
            'merchant_address'   => '',
            'price_mode'         => 'goldrush', // default to GoldRush
            'coingecko_platform' => 'base',
            'goldrush_api_key'   => '',
            'slippage_bps'       => 100,
            'confirmations'      => 3,
            'rpc_url'            => 'https://mainnet.base.org',
            'usi_only'           => 'no',
        ];
        $settings = get_option('woocommerce_usipay_settings', []);
        $settings = wp_parse_args($settings, $defaults);
        update_option('usipay_rpc_url', $settings['rpc_url']);
        return $settings;
    }

    public static function get_tokens() {
        $s = self::get_settings();
        $tokens = self::locked_tokens();
        if ( isset($s['usi_only']) && $s['usi_only'] === 'yes' ) {
            // return only USI
            return array_values(array_filter($tokens, function($t){
                return strtoupper($t['symbol']) === 'USI';
            }));
        }
        return $tokens;
    }

    public static function price_for_contract_usd($contract) {
        $settings = self::get_settings();
        $mode = $settings['price_mode'];
        $contractL = strtolower($contract);

        if ($mode === 'manual') {
            foreach ( self::locked_tokens() as $t ) {
                if ( strtolower($t['address']) === $contractL ) {
                    if ( isset($t['manual_usd']) ) return floatval($t['manual_usd']);
                }
            }
            return null;
        } elseif ($mode === 'coingecko') {
            $platform = $settings['coingecko_platform'] ?: 'base';
            $url = add_query_arg([
                'contract_addresses' => $contract,
                'vs_currencies'      => 'usd',
            ], "https://api.coingecko.com/api/v3/simple/token_price/{$platform}");
            $resp = wp_remote_get($url, ['timeout' => 15]);
            if ( is_wp_error($resp) ) return null;
            $body = json_decode(wp_remote_retrieve_body($resp), true);
            if ( isset($body[$contractL]['usd']) ) return floatval($body[$contractL]['usd']);
            return null;
        } elseif ($mode === 'goldrush') {
            $key = trim((string)$settings['goldrush_api_key']);
            if (!$key) return null;
            $chain_id = 8453;
            $url = "https://goldrush.dev/api/v1/pricing/tokens/{$chain_id}/address/{$contract}";
            $resp = wp_remote_get($url, [
                'timeout' => 15,
                'headers' => [ 'Authorization' => "Bearer {$key}" ]
            ]);
            if ( is_wp_error($resp) ) return null;
            $body = json_decode(wp_remote_retrieve_body($resp), true);
            if ( isset($body['data']['price']) ) return floatval($body['data']['price']);
            return null;
        }
        return null;
    }

    public static function calc_amount_for_order_total($contract, $decimals, $order_total_usd) {
        $price = self::price_for_contract_usd($contract);
        if ($price && $price > 0) {
            $tokens = $order_total_usd / $price;
        } else {
            $tokens = $order_total_usd;
        }
        return number_format($tokens, (int)$decimals, '.', '');
    }
}
