<?php
if ( ! defined( 'ABSPATH' ) ) exit;
class WC_Gateway_USI extends WC_Payment_Gateway {
    public function __construct() {
        $this->id = 'usipay'; $this->icon=''; $this->has_fields=true;
        $this->method_title = __('USI PAY', 'usi-pay');
        $this->method_description = __('Let customers pay with USDC or USI on Base. Token list is locked (USDC + USI). Optional USI-only mode.', 'usi-pay');
        $this->supports = ['products'];
        $this->init_form_fields(); $this->init_settings();
        $this->title = $this->get_option('title','USI PAY');
        $this->description = $this->get_option('description','Pay with USDC or USI on Base.');
        $this->enabled = $this->get_option('enabled','yes');
        $this->merchant = $this->get_option('merchant_address','');
        $this->rpc_url = $this->get_option('rpc_url','https://mainnet.base.org');
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this,'process_admin_options']);
        add_action('wp_enqueue_scripts', [$this,'maybe_enqueue_checkout_data']);
    }
    public function init_form_fields() {
        $this->form_fields = [
            'enabled'=>['title'=>__('Enable/Disable','usi-pay'),'type'=>'checkbox','label'=>__('Enable USI PAY','usi-pay'),'default'=>'yes'],
            'title'=>['title'=>__('Title','usi-pay'),'type'=>'text','description'=>__('Payment method title shown at checkout.','usi-pay'),'default'=>__('USI PAY','usi-pay')],
            'description'=>['title'=>__('Description','usi-pay'),'type'=>'textarea','description'=>__('Short description shown at checkout.','usi-pay'),'default'=>__('Connect your Base wallet to pay with USDC or USI.','usi-pay')],
            'merchant_address'=>['title'=>__('Merchant Wallet (Base)','usi-pay'),'type'=>'text','description'=>__('Address that will receive token payments.','usi-pay'),'default'=>''],
            'rpc_url'=>['title'=>__('Base RPC URL','usi-pay'),'type'=>'text','description'=>__('Public RPC: https://mainnet.base.org (or your own).','usi-pay'),'default'=>'https://mainnet.base.org'],
            'price_mode'=>['title'=>__('Pricing Mode','usi-pay'),'type'=>'select','description'=>__('How to convert order total (USD) to tokens.','usi-pay'),'default'=>'goldrush','options'=>['manual'=>__('Manual (USDC=1.0, USI custom)','usi-pay'),'coingecko'=>__('CoinGecko (by Base contract)','usi-pay'),'goldrush'=>__('GoldRush API (by address)','usi-pay')]],
            'coingecko_platform'=>['title'=>__('CoinGecko Platform','usi-pay'),'type'=>'text','default'=>'base'],
            'goldrush_api_key'=>['title'=>__('GoldRush API Key','usi-pay'),'type'=>'password','default'=>''],
            'usi_only'=>['title'=>__('USI-only Mode','usi-pay'),'type'=>'checkbox','label'=>__('Only accept USI (hide USDC)','usi-pay'),'default'=>'no'],
            'slippage_bps'=>['title'=>__('Slippage Tolerance (bps)','usi-pay'),'type'=>'number','default'=>'100'],
            'confirmations'=>['title'=>__('Confirmations Required','usi-pay'),'type'=>'number','default'=>'3'],
        ];
    }
    public function is_available() {
        if ( 'yes' !== $this->enabled ) return false;
        if ( empty($this->merchant) ) return false;
        if ( function_exists('WC') && WC()->cart ) {
            $total = 0;
            if (method_exists(WC()->cart,'get_totals')) { $totals = WC()->cart->get_totals(); $total = isset($totals['total']) ? floatval($totals['total']) : 0; }
            else { $total = floatval(WC()->cart->get_total('edit')); }
            if ( $total <= 0 ) return false;
        }
        return parent::is_available();
    }
    public function payment_fields() {
        echo wpautop( wp_kses_post( $this->description ) );
        $tokens = USIPAY_Utils::get_tokens();
        echo '<div id="usipay-ui" data-merchant="'.esc_attr($this->merchant).'">';
        echo '<div class="usipay-row"><button type="button" id="usipay-connect" class="button">'.esc_html__('Connect Wallet','usi-pay').'</button><span id="usipay-address"></span></div>';
        echo '<div class="usipay-row">';
        if ( count($tokens) > 1 ) {
            echo '<label>'.esc_html__('Pay with token','usi-pay').'</label><select id="usipay-token">';
            foreach ($tokens as $t) { printf('<option value="%s" data-decimals="%d">%s (%s)</option>', esc_attr($t['address']), intval($t['decimals']), esc_html($t['symbol']), esc_html($t['name'])); }
            echo '</select>';
        } else {
            $t = $tokens[0];
            printf('<input type="hidden" id="usipay-token" value="%s" data-decimals="%d" />', esc_attr($t['address']), intval($t['decimals']));
            echo '<span>'.esc_html($t['symbol'].' ('.$t['name'].')').'</span>';
        }
        echo '</div><div class="usipay-row"><span id="usipay-quote"></span></div>';
        echo '<div class="usipay-row"><button type="button" id="usipay-pay" class="button button-primary" disabled>'.esc_html__('Pay with Wallet','usi-pay').'</button></div>';
        echo '<div class="usipay-row"><small>'.esc_html__('After your wallet broadcasts the transaction, click "Place order" to finish.','usi-pay').'</small></div></div>';
    }
    public function validate_fields() {
        if ( empty($_POST['usipay_tx_hash']) ) { wc_add_notice(__('Please use the "Pay with Wallet" button to send the token payment first.','usi-pay'),'error'); return false; }
        return true;
    }
    public function process_payment($order_id) {
        $order = wc_get_order($order_id);
        $tx = sanitize_text_field($_POST['usipay_tx_hash'] ?? '');
        $from = sanitize_text_field($_POST['usipay_from'] ?? '');
        $token = sanitize_text_field($_POST['usipay_token_address'] ?? '');
        $amt = sanitize_text_field($_POST['usipay_amount'] ?? '');
        $dec = intval($_POST['usipay_decimals'] ?? 0);
        if ( ! $tx || ! $token || ! $amt ) { wc_add_notice(__('Missing payment data from wallet.','usi-pay'),'error'); return; }
        $order->update_meta_data('_usipay_tx_hash',$tx);
        $order->update_meta_data('_usipay_from',$from);
        $order->update_meta_data('_usipay_token_address',$token);
        $order->update_meta_data('_usipay_amount',$amt);
        $order->update_meta_data('_usipay_decimals',$dec);
        $order->update_meta_data('_usipay_tx_status','broadcast');
        $order->save();
        $order->update_status('on-hold', __('Awaiting on-chain confirmations for Base ERC-20 payment.','usi-pay'));
        return ['result'=>'success','redirect'=>$this->get_return_url($order)];
    }
    public function maybe_enqueue_checkout_data() {
        if ( is_checkout() ) {
            $tokens = USIPAY_Utils::get_tokens(); $total = 0;
            if ( function_exists('WC') && WC()->cart ) {
                if (method_exists(WC()->cart,'get_totals')) { $totals = WC()->cart->get_totals(); $total = isset($totals['total'])? floatval($totals['total']) : 0; }
                else { $total = floatval(WC()->cart->get_total('edit')); }
            }
            wp_localize_script('usipay-checkout','USIPAY_CFG',['merchant'=>$this->merchant,'tokens'=>$tokens,'orderTotal'=>$total]);
        }
    }
}
add_action('woocommerce_thankyou_usipay', function($order_id){
    $order = wc_get_order($order_id); if (!$order) return;
    $tx = $order->get_meta('_usipay_tx_hash');
    if ($tx) { echo '<p><strong>Transaction:</strong> <a href="https://basescan.org/tx/' . esc_attr($tx) . '" target="_blank" rel="noopener noreferrer">View on Basescan</a></p>'; }
});
