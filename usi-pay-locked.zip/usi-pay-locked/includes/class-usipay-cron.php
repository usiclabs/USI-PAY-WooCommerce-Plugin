<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class USIPAY_Cron {
    public static function init() { add_action('usipay_verify_tx_event', [__CLASS__, 'tick']); }

    public static function tick() {
        $args = [
            'limit'        => 10,
            'type'         => 'shop_order',
            'status'       => ['on-hold','pending'],
            'meta_key'     => '_usipay_tx_status',
            'meta_compare' => '!=',
            'meta_value'   => 'confirmed',
            'return'       => 'objects',
        ];
        $orders = wc_get_orders($args);
        if ( ! $orders ) return;
        foreach ( $orders as $order ) {
            $tx = $order->get_meta('_usipay_tx_hash');
            $token = $order->get_meta('_usipay_token_address');
            $amt   = $order->get_meta('_usipay_amount');
            $dec   = intval($order->get_meta('_usipay_decimals'));
            if ( ! $tx || ! $token || ! $amt || $dec < 0 ) continue;
            self::verify_order_tx($order, $tx, $token, $amt, $dec);
        }
    }

    protected static function rpc_call($method, $params = []) {
        $rpc = get_option('usipay_rpc_url', 'https://mainnet.base.org');
        $payload = ["jsonrpc"=>"2.0","method"=>$method,"params"=>$params,"id"=>uniqid('', true)];
        $resp = wp_remote_post($rpc, ['timeout'=>20,'headers'=>['Content-Type'=>'application/json'],'body'=> wp_json_encode($payload)]);
        if ( is_wp_error($resp) ) return $resp;
        $data = json_decode(wp_remote_retrieve_body($resp), true);
        if ( isset($data['error']) ) return new WP_Error('rpc_error', $data['error']['message']);
        return $data['result'];
    }

    protected static function verify_order_tx($order, $txhash, $token_contract, $expected_amount_human, $decimals) {
        $settings = USIPAY_Utils::get_settings();
        $merchant = strtolower(trim($settings['merchant_address']));
        if ( ! $merchant ) return;

        $receipt = self::rpc_call('eth_getTransactionReceipt', [$txhash]);
        if ( is_wp_error($receipt) || ! $receipt ) { return; }
        if ( empty($receipt['status']) || $receipt['status'] != '0x1' ) { return; }

        $blockNumberHex = isset($receipt['blockNumber']) ? $receipt['blockNumber'] : null;
        if ( ! $blockNumberHex ) return;

        $currentHex = self::rpc_call('eth_blockNumber', []);
        if ( ! $currentHex ) return;

        $confirms = hexdec($currentHex) - hexdec($blockNumberHex) + 1;
        if ( $confirms < intval($settings['confirmations']) ) {
            $order->add_order_note(sprintf('USI PAY: %d/%d confirmations for %s', $confirms, $settings['confirmations'], $txhash));
            $order->update_meta_data('_usipay_tx_status', 'confirming');
            $order->save();
            return;
        }

        $transferSig = '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef';
        $expected_wei = self::to_wei_string($expected_amount_human, $decimals);
        $logs = isset($receipt['logs']) ? $receipt['logs'] : [];
        $matched = false;

        foreach ( $logs as $log ) {
            if ( strtolower($log['address']) !== strtolower($token_contract) ) continue;
            if ( ! isset($log['topics'][0]) || strtolower($log['topics'][0]) !== $transferSig ) continue;
            if ( count($log['topics']) < 3 ) continue;
            $toTopic = $log['topics'][2];
            $toAddr = '0x' . substr($toTopic, 26);
            if ( strtolower($toAddr) !== $merchant ) continue;
            $valueHex = $log['data'];
            $value = self::hex_to_bigint($valueHex);
            if ( self::bigint_equal($value, $expected_wei) || self::within_slippage($value, $expected_wei, intval($settings['slippage_bps'])) ) {
                $matched = true; break;
            }
        }

        if ( $matched ) {
            $order->payment_complete($txhash);
            $order->add_order_note('USI PAY: Payment confirmed on Base. TX: ' . $txhash);
            $order->update_meta_data('_usipay_tx_status', 'confirmed');
            $order->save();
        } else {
            $order->add_order_note('USI PAY: TX confirmed but expected transfer not found to merchant address.');
        }
    }

    protected static function hex_to_bigint($hex) {
        $hex = strtolower($hex);
        $hex = preg_replace('/^0x/', '', $hex);
        $hex = ltrim($hex, '0');
        if ($hex === '') return '0';
        if ( function_exists('bcadd') ) {
            $dec = '0'; $len = strlen($hex);
            for ($i=0; $i<$len; $i++) { $current = hexdec($hex[$i]); $dec = bcmul($dec, '16', 0); $dec = bcadd($dec, (string)$current, 0); }
            return $dec;
        } else {
            return (string) hexdec(substr($hex, -15));
        }
    }

    protected static function to_wei_string($human, $decimals) {
        $human = (string)$human;
        if ( strpos($human, '.') === false ) { $fraction = ''; }
        else { list($whole, $fraction) = explode('.', $human, 2); $human = $whole; }
        $fraction = isset($fraction) ? rtrim($fraction, '0') : '';
        $fraction = substr($fraction, 0, (int)$decimals);
        $pad = max(0, $decimals - strlen($fraction));
        $wei = ltrim($human, '0') . $fraction . str_repeat('0', $pad);
        $wei = ltrim($wei, '0');
        return $wei === '' ? '0' : $wei;
    }

    protected static function bigint_equal($a, $b) {
        $a = ltrim($a, '0'); $b = ltrim($b, '0');
        if ($a === '') $a = '0'; if ($b === '') $b = '0';
        if (strlen($a) !== strlen($b)) return false;
        return strcmp($a, $b) === 0;
    }

    protected static function within_slippage($actual, $expected, $bps) {
        if ( function_exists('bccomp') && function_exists('bcmul') && function_exists('bcdiv') ) {
            $upper = bcadd($expected, bcdiv(bcmul($expected, (string)$bps, 0), '10000', 0), 0);
            $lower = bcsub($expected, bcdiv(bcmul($expected, (string)$bps, 0), '10000', 0), 0);
            if ( bccomp($actual, $lower, 0) >= 0 && bccomp($actual, $upper, 0) <= 0 ) return true;
            return false;
        } else {
            $a = floatval($actual); $e = floatval($expected);
            if ($e <= 0) return false;
            const_bps = ($bps/10000.0);
            return abs($a - $e)/$e <= const_bps;
        }
    }
}
USIPAY_Cron::init();
