<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( class_exists( '\\Automattic\\WooCommerce\\Blocks\\Payments\\Integrations\\AbstractPaymentMethodType' )
  && class_exists('\\Automattic\\WooCommerce\\Blocks\\Payments\\PaymentMethodRegistry') ) {
    final class USIPAY_Blocks extends \Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType {
        protected $name = 'usipay';
        public function initialize() { $this->settings = get_option( 'woocommerce_usipay_settings', [] ); }
        public function get_payment_method_script_handles() {
            $handle = 'usipay-blocks';
            wp_register_script($handle, USIPAY_URL . 'assets/js/blocks.js', [ 'wc-blocks-registry','wc-settings','wp-element','wp-i18n' ], USIPAY_VERSION, true);
            return [ $handle ];
        }
        public function is_active() {
            $enabled  = isset( $this->settings['enabled'] ) && 'yes' === $this->settings['enabled'];
            $has_addr = ! empty( $this->settings['merchant_address'] );
            return $enabled && $has_addr;
        }
        public function get_payment_method_data() {
            $tokens = USIPAY_Utils::get_tokens();
            $title  = isset($this->settings['title']) ? $this->settings['title'] : 'USI PAY';
            $desc   = isset($this->settings['description']) ? $this->settings['description'] : 'Pay with USDC or USI on Base.';
            $merchant = isset($this->settings['merchant_address']) ? $this->settings['merchant_address'] : '';
            $rpc = isset($this->settings['rpc_url']) ? $this->settings['rpc_url'] : 'https://mainnet.base.org';
            return [
                'title'=>$title,'description'=>$desc,'tokens'=>$tokens,'merchant'=>$merchant,'rpcUrl'=>$rpc,'chainId'=>'0x2105',
                'texts'=>['connect'=>__('Connect Wallet','usi-pay'),'payNow'=>__('Pay with Wallet','usi-pay')]
            ];
        }
    }
    add_action('woocommerce_blocks_payment_method_type_registration', function($payment_method_registry){ $payment_method_registry->register( new USIPAY_Blocks() ); });
}