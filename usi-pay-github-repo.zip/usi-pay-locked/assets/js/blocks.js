(function(){
    if (!window.wc || !window.wc.wcBlocksRegistry || !window.wc.wcSettings) { return; }
    const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
    const settings = window.wc.wcSettings.getSetting('usipay_data', {});
    const Label = () => wp.element.createElement('span', null, settings.title || 'USI PAY');
    const Content = () => wp.element.createElement(
        'div', { id:'usipay-ui', 'data-merchant': settings.merchant || '' },
        wp.element.createElement('div', { className:'usipay-row' },
            wp.element.createElement('button', { type:'button', id:'usipay-connect', className:'button' }, (settings.texts && settings.texts.connect) || 'Connect Wallet'),
            wp.element.createElement('span', { id:'usipay-address' })
        ),
        wp.element.createElement('div', { className:'usipay-row' },
            (settings.tokens && settings.tokens.length > 1)
              ? wp.element.createElement('select', { id:'usipay-token' },
                    settings.tokens.map(function(t, i){ return wp.element.createElement('option', { key:i, value:t.address, 'data-decimals':t.decimals }, t.symbol + ' (' + t.name + ')'); })
                )
              : (function(){ if (settings.tokens && settings.tokens.length === 1) { const t = settings.tokens[0]; return wp.element.createElement('span', null, t.symbol + ' (' + t.name + ')', wp.element.createElement('input', { type:'hidden', id:'usipay-token', value:t.address, 'data-decimals':t.decimals })); } return null; })()
        ),
        wp.element.createElement('div', { className:'usipay-row' }, wp.element.createElement('span', { id:'usipay-quote' })),
        wp.element.createElement('div', { className:'usipay-row' }, wp.element.createElement('button', { type:'button', id:'usipay-pay', className:'button button-primary', disabled:true }, (settings.texts && settings.texts.payNow) || 'Pay with Wallet')),
        wp.element.createElement('input', { type:'hidden', id:'usipay_tx_hash', name:'usipay_tx_hash' }),
        wp.element.createElement('input', { type:'hidden', id:'usipay_from', name:'usipay_from' }),
        wp.element.createElement('input', { type:'hidden', id:'usipay_token_address', name:'usipay_token_address' }),
        wp.element.createElement('input', { type:'hidden', id:'usipay_amount', name:'usipay_amount' }),
        wp.element.createElement('input', { type:'hidden', id:'usipay_decimals', name:'usipay_decimals' })
    );
    const getPaymentMethodData = () => {
        const ids = ['usipay_tx_hash','usipay_from','usipay_token_address','usipay_amount','usipay_decimals'];
        const data = {}; ids.forEach(function(id){ data[id] = document.getElementById(id)?.value || ''; }); return data;
    };
    registerPaymentMethod({ name:'usipay', label:Label, ariaLabel:settings.title || 'USI PAY', canMakePayment:() => true, content:Content, edit:Content, supports:{ features:['products'] }, paymentMethodId:'usipay', getPaymentMethodData });
})();