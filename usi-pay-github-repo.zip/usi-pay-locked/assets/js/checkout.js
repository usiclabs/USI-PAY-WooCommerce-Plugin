(function($){
    async function ensureBase() {
        if (!window.ethereum) throw new Error("No wallet. Use a Base-compatible wallet.");
        const target = USIPAY.chainId;
        const current = await window.ethereum.request({ method: 'eth_chainId' });
        if (current !== target) {
            try { await window.ethereum.request({ method:'wallet_switchEthereumChain', params:[{ chainId: target }] }); }
            catch (e) {
                if (e && e.code === 4902) {
                    await window.ethereum.request({ method:'wallet_addEthereumChain', params:[{ chainId:target, chainName:'Base Mainnet', rpcUrls:[USIPAY.rpcUrl], nativeCurrency:{ name:'ETH', symbol:'ETH', decimals:18 }, blockExplorerUrls:['https://basescan.org/'] }] });
                } else { throw e; }
            }
        }
    }
    function getTokenSelection() {
        const el = document.getElementById('usipay-token'); if (!el) return null;
        if (el.tagName && el.tagName.toLowerCase() === 'select') {
            const address = el.value; const decimals = parseInt(el.selectedOptions[0].getAttribute('data-decimals')); return { address, decimals };
        } else { const address = el.value; const decimals = parseInt(el.getAttribute('data-decimals')); return { address, decimals }; }
    }
    function humanToUnitsStr(amountHuman, decimals) {
        const parts = String(amountHuman).split('.'); const whole = parts[0] || '0'; const fracRaw = parts[1] || '';
        const frac = (fracRaw + '0'.repeat(decimals)).slice(0, decimals); return whole + frac;
    }
    async function connectWallet() {
        if (!window.ethereum) { alert("Wallet not detected."); return; }
        await ensureBase();
        const provider = new ethers.providers.Web3Provider(window.ethereum, 'any');
        await provider.send("eth_requestAccounts", []);
        const signer = provider.getSigner(); const account = await signer.getAddress();
        jQuery('#usipay-address').text(account);
        jQuery('#usipay-pay').prop('disabled', false);
        updateQuote();
    }
    async function updateQuote() {
        try {
            const t = getTokenSelection(); if (!t) return;
            const url = `${USIPAY.rest_root}quote?contract=${encodeURIComponent(t.address)}&decimals=${t.decimals}&order_total=${encodeURIComponent(USIPAY_CFG.orderTotal)}`;
            const res = await fetch(url); const data = await res.json();
            if (data && data.amount) { jQuery('#usipay-quote').text(`You will pay ~ ${data.amount} tokens`); }
            else { jQuery('#usipay-quote').text('Quote unavailable; assuming 1 token = 1 USD.'); }
        } catch (e) { jQuery('#usipay-quote').text('Quote unavailable.'); }
    }
    async function payWithWallet() {
        try {
            jQuery('#usipay-pay').prop('disabled', true);
            await ensureBase();
            const t = getTokenSelection(); if (!t) throw new Error("Select a token");
            const qres = await fetch(`${USIPAY.rest_root}quote?contract=${encodeURIComponent(t.address)}&decimals=${t.decimals}&order_total=${encodeURIComponent(USIPAY_CFG.orderTotal)}`);
            const qdata = await qres.json(); const amountHuman = qdata && qdata.amount ? qdata.amount : String(USIPAY_CFG.orderTotal);
            const unitsStr = humanToUnitsStr(amountHuman, t.decimals);
            const unitsHex = '0x' + BigInt(unitsStr).toString(16);
            const amount = ethers.BigNumber.from(unitsHex);
            const provider = new ethers.providers.Web3Provider(window.ethereum, 'any');
            const signer = provider.getSigner();
            const token = new ethers.Contract(t.address, ["function transfer(address to, uint256 amount) public returns (bool)"], signer);
            const tx = await token.transfer(USIPAY_CFG.merchant, amount);
            const receipt = await tx.wait(1);
            jQuery('#usipay_tx_hash').val(receipt.transactionHash);
            jQuery('#usipay_from').val(await signer.getAddress());
            jQuery('#usipay_token_address').val(t.address);
            jQuery('#usipay_amount').val(amountHuman);
            jQuery('#usipay_decimals').val(t.decimals);
            alert(USIPAY.texts.paid);
        } catch (e) { console.error(e); alert("Payment failed or cancelled: " + (e && e.message ? e.message : e)); }
        finally { jQuery('#usipay-pay').prop('disabled', false); }
    }
    jQuery(document).on('click','#usipay-connect',connectWallet);
    jQuery(document).on('click','#usipay-pay',payWithWallet);
    jQuery(document).on('change','#usipay-token',updateQuote);
    jQuery(document.body).on('updated_checkout wc-credit-card-form-init',updateQuote);
})(jQuery);
