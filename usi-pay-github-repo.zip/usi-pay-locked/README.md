# USI PAY (WooCommerce Gateway for Base)

A WooCommerce payment gateway that accepts **USDC** and **USI** on **Base (chainId 8453)**.

## Features
- Locked tokens: **USDC (Base)** and **USI**; **USI-only** toggle
- Checkout Blocks + classic shortcode support
- Server-side on-chain verification of ERC-20 payments
- Pricing via GoldRush (default), CoinGecko, or Manual
- HPOS (custom order tables) compatible
- Basescan transaction link on Thank You page

## Install
- Use the plugin ZIP from Releases to install via WordPress admin.

## Configure
- WooCommerce → Settings → Payments → **USI PAY**
  - Merchant Wallet (Base) — required
  - Base RPC URL — default `https://mainnet.base.org`
  - Pricing Mode — `goldrush` (default) / `coingecko` / `manual`
  - USI-only Mode — accept only USI
  - Slippage (bps) — default 100
  - Confirmations — default 3

## Dev Layout
- Gateway: `includes/class-wc-gateway-usi.php`
- Utils/Pricing: `includes/class-usipay-utils.php`
- REST: `includes/class-usipay-rest.php`
- Verifier: `includes/class-usipay-cron.php`
- Blocks: `includes/class-usipay-blocks.php`, `assets/js/blocks.js`
- Frontend: `assets/js/checkout.js`, `assets/css/checkout.css`

## License
GPL-2.0-or-later
