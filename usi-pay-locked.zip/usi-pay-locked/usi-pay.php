<?php
/**
 * Plugin Name: USI PAY
 * Plugin URI:  https://usiclabs.com/
 * Description: Accept USDC and USI on Base (chainId 8453) as a WooCommerce payment method. Locked token list (USDC+USI), optional USI-only mode, wallet checkout, and on-chain verification.
 * Version:     1.2.0
 * Author:      USIC Labs
 * Requires PHP: 7.4
 * Requires at least: 5.8
 * WC requires at least: 5.0
 * WC tested up to: 9.0
 * License:     GPLv2 or later
 * Text Domain: usi-pay
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define('USIPAY_VERSION', '1.2.0');
define('USIPAY_FILE', __FILE__);
define('USIPAY_DIR', plugin_dir_path(__FILE__));
define('USIPAY_URL', plugin_dir_url(__FILE__));

add_action('plugins_loaded', function() {
    if ( ! class_exists( 'WC_Payment_Gateway' ) ) { return; }
    require_once USIPAY_DIR . 'includes/class-usipay-utils.php';
    require_once USIPAY_DIR . 'includes/class-usipay-rest.php';
    require_once USIPAY_DIR . 'includes/class-usipay-cron.php';
    require_once USIPAY_DIR . 'includes/class-wc-gateway-usi.php';

    add_filter('woocommerce_payment_gateways', function($methods){
        $methods[] = 'WC_Gateway_USI';
        return $methods;
    });
});

add_action('wp_enqueue_scripts', function(){
    if ( function_exists('is_checkout') && is_checkout() ) {
        wp_enqueue_script('ethers', 'https://cdn.jsdelivr.net/npm/ethers@5.7.2/dist/ethers.umd.min.js', [], '5.7.2', true);
        wp_enqueue_script('usipay-checkout', USIPAY_URL . 'assets/js/checkout.js', ['jquery','ethers'], USIPAY_VERSION, true);
        $settings = USIPAY_Utils::get_settings();
        wp_localize_script('usipay-checkout', 'USIPAY', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'rest_root' => esc_url_raw( rest_url('usipay/v1/') ),
            'chainId'  => '0x2105',
            'rpcUrl'   => $settings['rpc_url'],
            'texts'    => [
                'connect' => __('Connect Wallet', 'usi-pay'),
                'payNow'  => __('Pay with Wallet', 'usi-pay'),
                'paid'    => __('Payment broadcast. You can place the order now.', 'usi-pay'),
            ]
        ]);
        wp_enqueue_style('usipay-style', USIPAY_URL . 'assets/css/checkout.css', [], USIPAY_VERSION);
    }
});

add_action('woocommerce_review_order_before_submit', function(){
    ?>
    <input type="hidden" id="usipay_tx_hash" name="usipay_tx_hash" value="">
    <input type="hidden" id="usipay_from" name="usipay_from" value="">
    <input type="hidden" id="usipay_token_address" name="usipay_token_address" value="">
    <input type="hidden" id="usipay_amount" name="usipay_amount" value="">
    <input type="hidden" id="usipay_decimals" name="usipay_decimals" value="">
    <?php
});

register_activation_hook(__FILE__, function(){
    if ( ! wp_next_scheduled('usipay_verify_tx_event') ) {
        wp_schedule_event(time() + 60, 'minute', 'usipay_verify_tx_event');
    }
});
register_deactivation_hook(__FILE__, function(){
    $ts = wp_next_scheduled('usipay_verify_tx_event');
    if ($ts) { wp_unschedule_event($ts, 'usipay_verify_tx_event'); }
});

add_filter('cron_schedules', function($s){
    if ( ! isset($s['minute']) ) {
        $s['minute'] = [ 'interval' => 60, 'display' => __('Every Minute','usi-pay') ];
    }
    return $s;
});
