# USI PAY — WooCommerce payments with USDC & USI on Base (locked list, USI-only toggle)

**USI PAY** is a WooCommerce payment gateway for **Base (chainId 8453)** that lets customers pay with **USDC** and **USI** only. The token list is **locked** to these two assets, and there’s a **USI-only** toggle in settings to hide USDC. Includes wallet checkout (ethers.js) and **server-side on-chain verification** that confirms transfers to your merchant address and auto-completes orders after the required confirmations.

## Features
- **Locked token list:** **USDC (Base)** and **USI** (`0x987603A52d8B966E10FBD29DcB1A574049E25B07`)
- **USI-only mode:** enable a checkbox in settings to accept **only USI**
- **Wallet UX:** Connect → Quote → `transfer()` → Place order
- **On-chain verification:** cron parses ERC-20 `Transfer` logs to your merchant address; matches amount ± slippage; waits confirmations; marks order paid
- **Pricing sources:** GoldRush (default) by address, CoinGecko by Base contract, or Manual (e.g., USDC = 1.0)
- **Thank You page:** Basescan link to the transaction

## Requirements
- WordPress 5.8+ / WooCommerce 5.0+
- PHP 7.4+ (compatible with 8.x)
- Base-compatible wallet
- Optional: GoldRush API key for live pricing

## Install
1. Upload the ZIP via **Plugins → Add New → Upload Plugin**.
2. Activate **USI PAY**.
3. WooCommerce → **Settings → Payments → USI PAY** → Enable.

## Configure
- **Merchant Wallet (Base):** your receive address.
- **Base RPC:** defaults to `https://mainnet.base.org` (use your provider for production).
- **USI-only mode:** toggle to hide USDC and accept only USI.
- **Pricing mode:** GoldRush (default), CoinGecko, or Manual; adjust **Slippage bps** and **Confirmations** as needed.

## How it works
1. Shopper selects **USI PAY** and connects their Base wallet.
2. Plugin fetches a **quote** for the selected token (USDC or USI).
3. Shopper clicks **Pay with Wallet** — an ERC-20 `transfer()` is sent to your merchant address.
4. Order goes **On‑Hold**; background verifier checks the tx receipt & logs.
5. After the configured confirmations, the order is marked **Paid**. Thank You page shows a Basescan link.

## Development
- Frontend: `assets/js/checkout.js` (ethers.js), `assets/css/checkout.css`
- Backend: `includes/class-wc-gateway-usi.php`, `includes/class-usipay-utils.php`, `includes/class-usipay-rest.php`, `includes/class-usipay-cron.php`

## License
GPLv2 or later.
