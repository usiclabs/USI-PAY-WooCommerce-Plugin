# Changelog

## 1.3.0
- HPOS & Blocks compatibility declared (includes `cart_checkout_blocks`)
- Translation-ready (loads `usi-pay` textdomain)
- BCMath admin notice (optional)
- Gateway availability checks (enabled, merchant address, non-zero total)
- Blocks adapter requires merchant address
- Hardened Blocks integration guards

## 1.2.0
- Hardened Blocks integration and HPOS-safe order handling

## 1.1.0
- Locked tokens (USDC + USI) + USI-only toggle
- GoldRush default pricing, CoinGecko/Manual options

## 1.0.0
- Initial release
