<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class USIPAY_REST {
    public static function init() { add_action('rest_api_init', [__CLASS__, 'routes']); }
    public static function routes() {
        register_rest_route('usipay/v1', '/quote', [
            'methods'=>'GET','callback'=>[__CLASS__,'quote'],'permission_callback'=>'__return_true'
        ]);
        register_rest_route('usipay/v1', '/latest-block', [
            'methods'=>'GET','callback'=>[__CLASS__,'latest_block'],'permission_callback'=>'__return_true'
        ]);
    }
    public static function quote( WP_REST_Request $req ) {
        $contract = sanitize_text_field($req->get_param('contract'));
        $decimals = intval($req->get_param('decimals'));
        $total    = floatval($req->get_param('order_total'));
        if ( ! $contract || $decimals < 0 || $total <= 0 ) {
            return new WP_REST_Response(['error' => 'Invalid params'], 400);
        }
        $amt = USIPAY_Utils::calc_amount_for_order_total($contract, $decimals, $total);
        $price = USIPAY_Utils::price_for_contract_usd($contract);
        return [ 'amount' => $amt, 'price' => $price ];
    }
    public static function latest_block( WP_REST_Request $req ) {
        $rpc = get_option('usipay_rpc_url', 'https://mainnet.base.org');
        $payload = [ "jsonrpc"=>"2.0", "method"=>"eth_blockNumber", "params"=>[], "id"=>1 ];
        $resp = wp_remote_post($rpc, ['timeout'=>15,'headers'=>['Content-Type'=>'application/json'],'body'=> wp_json_encode($payload)]);
        if ( is_wp_error($resp) ) return new WP_REST_Response(['error'=>$resp->get_error_message()], 500);
        return json_decode(wp_remote_retrieve_body($resp), true);
    }
}
USIPAY_REST::init();
